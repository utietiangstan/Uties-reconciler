UTIES RECONCILER — SETUP GUIDE
=============================================

WHAT THIS IS
"Uties Reconciler" is a single small offline-first app for running the
daily numbers of a fuel station business in Nigeria — pump/tank sales,
generator diesel, incoming
deliveries, product shortages, a supermarket/restaurant side business,
staff attendance and salary, other expenses and levies, cash till and
bank reconciliation, safety compliance, and a security incident log.
Designed to work fully with no or poor internet.

WHAT'S NEW IN THIS VERSION
  - Dip-vs-meter reconciliation: enter the tank dip reading AND the pump
    meter reading, and the app calculates the variance automatically —
    the standard early-warning sign of a leak, theft, or a faulty meter.
  - Product Shortage Log: record every stock-out or withdrawal (product,
    start/end time, reason, estimated litres short, customers turned
    away, estimated lost revenue) plus a running "most common cause"
    analysis across history, so you can see whether the fix is a bigger
    tank, a backup supplier, or pump maintenance.
  - Delivery log with ordered-vs-received checking, seal/sample checks,
    to catch short deliveries before the truck leaves.
  - Generator diesel tracked separately from pump stock, plus NEPA/grid
    hours, so you can see your true daily power cost.
  - Supermarket & restaurant tab with spoilage tracking (common silent
    loss for perishables in Nigerian heat).
  - Staff attendance and a payroll tab (advances/deductions handled).
  - Expense categories pre-loaded for typical Nigerian station costs:
    security levy, NUPENG/PTD & association dues, DPR/NMDPRA and local
    government levies, informal/task-force charges, maintenance, etc.
  - Payment-mix tracking (cash / POS / transfer / credit) — useful given
    how often POS network downtime shifts more of the day onto cash.
  - Credit customer / debtor ledger with running balances.
  - Cash till reconciliation (opening float, cash paid out of the till,
    expected vs counted cash, variance) and a separate bank lodgement
    record.
  - Daily safety/compliance checklist (extinguishers, spill kit,
    calibration seals, water-in-fuel paste test, DPR permit, PPE) and a
    security incident log for theft/drive-offs/disputes.
  - Dashboard with automatic alerts (variance, low stock, open shortage,
    till mismatch, unpaid debtors) and simple built-in charts — no
    external chart library, so it stays small and works offline.
  - A CEO/Director view that combines every imported manager's file into
    one overview and a per-station comparison table.
  - Export to CSV (for Excel) as well as the .json backup/share file.
  - "Print day report" button for a clean paper printout to file
    physically, which many stations still keep as a backup habit.

OPTION 1 — USE IT RIGHT NOW, NO SETUP (single device)
Just double-click index.html and it opens in your browser. Everything
you enter is saved on that device only, in that browser. Good for one
manager working from one phone or laptop.
Limitation: if you clear browser data/cache, saved entries are lost —
export a backup regularly (Settings & Data > Export all data).

OPTION 2 — HOST IT SO IT'S A REAL INSTALLABLE APP (recommended)
Host the whole "reconciliation-app" folder for free on Netlify:
  1. Go to netlify.com, sign in, choose "Add new site" > "Deploy manually"
  2. Drag the whole reconciliation-app folder onto the upload area
  3. Netlify gives you a link like https://yourname.netlify.app
Once hosted over https, anyone who opens that link on a phone can tap
"Add to Home Screen" (Chrome/Android) or Share > "Add to Home Screen"
(Safari/iOS) — it then behaves like a real installed app icon, and
keeps working offline after the first visit because of the built-in
service worker (sw.js).

HOW MULTIPLE PEOPLE SHARE DATA (no server, no live sync)
There's no cloud database here — each device keeps its own local copy,
which is what lets it work with zero data cost and no dependence on a
connection. To move numbers between people:
  1. Manager enters the day's figures across the tabs as the day goes on
  2. At day's end, manager opens Settings & Data and taps
     "Export all data (.json)" — this downloads a small file
  3. Manager sends that file to the CEO/Director over WhatsApp, email,
     or a shared drive — whatever is already reliable in your area
  4. CEO/Director opens their own copy of the app, switches to
     "CEO / Director view" (top right), goes to Settings & Data, and
     taps "Import data (.json)" — their combined dashboard updates with
     that manager's numbers, kept separate per station so several
     managers can be imported into one Director device without mixing
     up their figures.
This is manual by design: it removes the need for constant internet or
a paid server, which matters given connectivity costs in much of
Nigeria. If you later want live, automatic syncing across devices, that
requires a real backend server — a different (and paid) kind of build.

GETTING STARTED — RECOMMENDED FIRST STEPS
  1. Open Settings & Data and set your station name, manager name, and
     currency symbol.
  2. Check the Products & Tanks list — PMS, AGO, DPK and Cooking Gas are
     pre-loaded; edit tank capacities so the low-stock warning is
     accurate, or add/remove products to match what you sell.
  3. Check the Pumps list matches your physical pumps/nozzles.
  4. Set your generator diesel price and your preferred variance/
     low-stock alert thresholds.
  5. Each day, work through the tabs in order: Fuel & Tanks, Deliveries
     (if any), Shortages (if any), Generator & Power, Shop & Restaurant,
     Staff & Salary, Expenses, Payments & Debtors, then Till & Bank to
     close out, and Safety & Security as a last daily habit.
  6. Export a backup before closing the browser for the day.

FILES IN THIS FOLDER
  index.html     — the app shell (this is the only file you need for Option 1)
  app.js         — all the app logic
  manifest.json  — lets phones install it as an app icon (Option 2)
  sw.js          — makes it work offline once hosted (Option 2)
  icon-192.png, icon-512.png — app icons

DATA COST NOTE
After the first load, the app makes zero network requests — no fonts,
no chart library, no ads — everything is drawn with built-in browser
tools. The only network use is if you re-host an update or share an
export file.

A NOTE ON THE NUMBERS
This app is a records and reconciliation tool, not an accounting system
— "Net profit (est.)" and similar figures are a same-day estimate meant
to surface problems quickly (a bad till count, a slipping margin, a
recurring stock-out), not a replacement for your official books.

SHARING WITH OTHER STATIONS
Uties Reconciler was built to be reused — nothing in it is tied to one
station's data. To set another station up, just copy this whole folder
(or send them the single-file version) and have them fill in their own
station name in Settings & Data; their entries stay completely separate
from yours since each install has its own station ID.
